package com.taxi.controller;

import com.taxi.dto.FareEstimateRequest;
import com.taxi.dto.FareEstimateResult;
import com.taxi.model.Passenger;
import com.taxi.model.RideRequest;
import com.taxi.service.TaxiFeatureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Feature 3: Ride Fare Calculator with Multiple Stop Support
 * Base path: /fare
 */
@RestController
@RequestMapping("/fare")
public class FareController {

    @Autowired
    private TaxiFeatureService taxiFeatureService;

    // POST /fare/estimate  — estimate fare for a multi-stop ride
    @PostMapping("/estimate")
    public ResponseEntity<FareEstimateResult> estimateFare(
            @RequestBody FareEstimateRequest request) {
        return ResponseEntity.ok(taxiFeatureService.estimateFare(request));
    }

    // POST /fare/passengers  — register a passenger
    @PostMapping("/passengers")
    public ResponseEntity<Passenger> savePassenger(@RequestBody Passenger passenger) {
        return ResponseEntity.ok(taxiFeatureService.savePassenger(passenger));
    }

    // GET /fare/passengers  — get all passengers
    @GetMapping("/passengers")
    public ResponseEntity<List<Passenger>> getAllPassengers() {
        return ResponseEntity.ok(taxiFeatureService.getAllPassengers());
    }

    // POST /fare/rides  — save a completed ride with final fare
    @PostMapping("/rides")
    public ResponseEntity<RideRequest> saveRide(@RequestBody RideRequest ride) {
        return ResponseEntity.ok(taxiFeatureService.saveRide(ride));
    }

    // GET /fare/rides  — get all rides
    @GetMapping("/rides")
    public ResponseEntity<List<RideRequest>> getAllRides() {
        return ResponseEntity.ok(taxiFeatureService.getAllRides());
    }

    // GET /fare/rides/{rideId}  — get a specific ride
    @GetMapping("/rides/{rideId}")
    public ResponseEntity<RideRequest> getRideById(@PathVariable Long rideId) {
        return ResponseEntity.ok(taxiFeatureService.getRideById(rideId));
    }

    // GET /fare/rides/pending  — get all PENDING rides (driver notification feed)
    @GetMapping("/rides/pending")
    public ResponseEntity<List<RideRequest>> getPendingRides() {
        return ResponseEntity.ok(
            taxiFeatureService.getAllRides().stream()
                .filter(r -> "PENDING".equals(r.getStatus()))
                .collect(java.util.stream.Collectors.toList())
        );
    }

    // PATCH /fare/rides/{rideId}/accept?driverId=X  — driver accepts a ride
    @PatchMapping("/rides/{rideId}/accept")
    public ResponseEntity<RideRequest> acceptRide(
            @PathVariable Long rideId,
            @RequestParam Long driverId) {
        RideRequest ride = taxiFeatureService.getRideById(rideId);
        ride.setDriverId(driverId);
        ride.setStatus("MATCHED");
        return ResponseEntity.ok(taxiFeatureService.saveRide(ride));
    }

    // PATCH /fare/rides/{rideId}/status  — update ride status (ACTIVE, COMPLETED, CANCELLED)
    @PatchMapping("/rides/{rideId}/status")
    public ResponseEntity<RideRequest> updateRideStatus(
            @PathVariable Long rideId,
            @RequestParam String status) {
        RideRequest ride = taxiFeatureService.getRideById(rideId);
        ride.setStatus(status);
        return ResponseEntity.ok(taxiFeatureService.saveRide(ride));
    }
}
