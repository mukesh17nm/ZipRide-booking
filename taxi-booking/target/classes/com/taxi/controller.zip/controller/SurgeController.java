package com.taxi.controller;

import com.taxi.dto.SurgePriceRequest;
import com.taxi.dto.SurgePriceResult;
import com.taxi.service.TaxiFeatureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Feature 2: Surge Pricing Calculator
 * Base path: /surge
 */
@RestController
@RequestMapping("/surge")
public class SurgeController {

    @Autowired
    private TaxiFeatureService taxiFeatureService;

    // POST /surge/compute  — compute surge for a zone and return priced fare
    @PostMapping("/compute")
    public ResponseEntity<SurgePriceResult> computeSurgePrice(
            @RequestBody SurgePriceRequest request) {
        return ResponseEntity.ok(taxiFeatureService.computeSurgePrice(request));
    }

    // GET /surge/by-zone  — Map<ZoneId, CurrentSurgeMultiplier> for all zones
    @GetMapping("/by-zone")
    public ResponseEntity<Map<String, Double>> getCurrentSurgeByZone() {
        return ResponseEntity.ok(taxiFeatureService.getCurrentSurgeByZone());
    }
}
