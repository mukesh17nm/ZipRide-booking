package com.taxi.controller;

import com.taxi.dto.RatingAndIncentiveResult;
import com.taxi.dto.RatingRequest;
import com.taxi.model.Driver;
import com.taxi.model.DriverRating;
import com.taxi.service.TaxiFeatureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Feature 4: Driver Rating and Incentive Engine
 * Base path: /rating
 */
@RestController
@RequestMapping("/rating")
public class RatingController {

    @Autowired
    private TaxiFeatureService taxiFeatureService;

    // POST /rating/submit  — submit a rating and trigger incentive computation
    @PostMapping("/submit")
    public ResponseEntity<RatingAndIncentiveResult> submitRating(
            @RequestBody RatingRequest request) {
        return ResponseEntity.ok(taxiFeatureService.submitRatingAndComputeIncentive(request));
    }

    // GET /rating/driver/{driverId}  — get all ratings for a driver
    @GetMapping("/driver/{driverId}")
    public ResponseEntity<List<DriverRating>> getRatingsByDriver(@PathVariable Long driverId) {
        return ResponseEntity.ok(taxiFeatureService.getRatingsByDriver(driverId));
    }

    // GET /rating/warned  — get all drivers with a warning flag
    @GetMapping("/warned")
    public ResponseEntity<List<Driver>> getWarnedDrivers() {
        return ResponseEntity.ok(taxiFeatureService.getWarnedDrivers());
    }
}
