package com.taxi.controller;

import com.taxi.dto.DriverMatchRequest;
import com.taxi.dto.DriverMatchResult;
import com.taxi.model.Driver;
import com.taxi.service.TaxiFeatureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Feature 1: Driver Matching and Nearest Cab Finder
 * Base path: /drivers
 */
@RestController
@RequestMapping("/drivers")
public class DriverController {

    @Autowired
    private TaxiFeatureService taxiFeatureService;

    // POST /drivers  — register a new driver
    @PostMapping
    public ResponseEntity<Driver> saveDriver(@RequestBody Driver driver) {
        return ResponseEntity.ok(taxiFeatureService.saveDriver(driver));
    }

    // GET /drivers  — get all drivers
    @GetMapping
    public ResponseEntity<List<Driver>> getAllDrivers() {
        return ResponseEntity.ok(taxiFeatureService.getAllDrivers());
    }

    // GET /drivers/{driverId}  — get a driver by id
    @GetMapping("/{driverId}")
    public ResponseEntity<Driver> getDriverById(@PathVariable Long driverId) {
        return ResponseEntity.ok(taxiFeatureService.getDriverById(driverId));
    }

    // PATCH /drivers/{driverId}/status?status=AVAILABLE  — update driver status
    @PatchMapping("/{driverId}/status")
    public ResponseEntity<Driver> updateDriverStatus(
            @PathVariable Long driverId,
            @RequestParam String status) {
        return ResponseEntity.ok(taxiFeatureService.updateDriverStatus(driverId, status));
    }

    // POST /drivers/match  — find top N nearest available drivers for a ride request
    @PostMapping("/match")
    public ResponseEntity<DriverMatchResult> findNearestDrivers(
            @RequestBody DriverMatchRequest request) {
        return ResponseEntity.ok(taxiFeatureService.findNearestDrivers(request));
    }

    // GET /drivers/available-by-zone  — Map<ZoneId, AvailableDriverCount>
    @GetMapping("/available-by-zone")
    public ResponseEntity<Map<String, Integer>> getAvailableDriverCountByZone() {
        return ResponseEntity.ok(taxiFeatureService.getAvailableDriverCountByZone());
    }
}
