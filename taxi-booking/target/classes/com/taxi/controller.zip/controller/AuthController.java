package com.taxi.controller;

import com.taxi.dto.ForgotPasswordRequest;
import com.taxi.dto.LoginRequest;
import com.taxi.dto.SignupRequest;
import com.taxi.model.AppUser;
import com.taxi.repository.AppUserRepository;
import com.taxi.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Authentication Controller — Signup, Login, Forgot Password with JWT.
 */
@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AppUserRepository appUserRepository;

    @Autowired
    private JwtUtil jwtUtil;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    /** POST /api/auth/signup */
    @PostMapping("/signup")
    public ResponseEntity<Map<String, Object>> signup(@RequestBody SignupRequest request) {
        Map<String, Object> response = new HashMap<>();

        if (request.getFullName() == null || request.getFullName().isBlank()) {
            response.put("success", false);
            response.put("message", "Full name is required.");
            return ResponseEntity.badRequest().body(response);
        }
        if (request.getPassword() == null || request.getPassword().length() < 6) {
            response.put("success", false);
            response.put("message", "Password must be at least 6 characters.");
            return ResponseEntity.badRequest().body(response);
        }
        if (appUserRepository.existsByEmail(request.getEmail())) {
            response.put("success", false);
            response.put("message", "Email already registered: " + request.getEmail());
            return ResponseEntity.badRequest().body(response);
        }

        java.util.Set<String> validRoles = java.util.Set.of("PASSENGER", "DRIVER", "ADMIN");
        String role = request.getRole() != null ? request.getRole().toUpperCase() : "PASSENGER";
        if (!validRoles.contains(role)) {
            response.put("success", false);
            response.put("message", "Invalid role: " + role);
            return ResponseEntity.badRequest().body(response);
        }

        AppUser user = new AppUser();
        user.setFullName(request.getFullName());
        user.setEmail(request.getEmail().toLowerCase());
        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        user.setPhoneNumber(request.getPhoneNumber());
        user.setRole(role);
        user.setCreatedAt(LocalDateTime.now());
        user.setActive(true);

        AppUser saved = appUserRepository.save(user);

        response.put("success", true);
        response.put("message", "Account created successfully. Please login.");
        response.put("userId", saved.getId());
        response.put("email", saved.getEmail());
        response.put("role", saved.getRole());
        return ResponseEntity.ok(response);
    }

    /** POST /api/auth/login */
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody LoginRequest request) {
        Map<String, Object> response = new HashMap<>();

        AppUser user = appUserRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);

        if (user == null) {
            response.put("success", false);
            response.put("message", "No account found with email: " + request.getEmail());
            return ResponseEntity.status(401).body(response);
        }
        if (!user.isActive()) {
            response.put("success", false);
            response.put("message", "Account is deactivated. Please contact support.");
            return ResponseEntity.status(403).body(response);
        }
        if (!passwordEncoder.matches(request.getPassword(), user.getPasswordHash())) {
            response.put("success", false);
            response.put("message", "Invalid password. Please try again.");
            return ResponseEntity.status(401).body(response);
        }

        String token = jwtUtil.generateToken(user.getEmail(), user.getRole(), user.getId());

        response.put("success", true);
        response.put("message", "Login successful. Welcome, " + user.getFullName() + "!");
        response.put("token", token);
        response.put("userId", user.getId());
        response.put("fullName", user.getFullName());
        response.put("email", user.getEmail());
        response.put("role", user.getRole());
        return ResponseEntity.ok(response);
    }

    /**
     * POST /api/auth/forgot-password
     * Verify email exists → set new password directly.
     * (In production, send reset email with OTP — this is demo version)
     */
    @PostMapping("/forgot-password")
    public ResponseEntity<Map<String, Object>> forgotPassword(@RequestBody ForgotPasswordRequest request) {
        Map<String, Object> response = new HashMap<>();

        // Validate email
        if (request.getEmail() == null || request.getEmail().isBlank()) {
            response.put("success", false);
            response.put("message", "Email is required.");
            return ResponseEntity.badRequest().body(response);
        }

        // Check user exists
        AppUser user = appUserRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if (user == null) {
            response.put("success", false);
            response.put("message", "No account found with email: " + request.getEmail());
            return ResponseEntity.status(404).body(response);
        }

        // Validate new password
        if (request.getNewPassword() == null || request.getNewPassword().length() < 6) {
            response.put("success", false);
            response.put("message", "New password must be at least 6 characters.");
            return ResponseEntity.badRequest().body(response);
        }

        // Validate confirm password
        if (!request.getNewPassword().equals(request.getConfirmPassword())) {
            response.put("success", false);
            response.put("message", "Passwords do not match.");
            return ResponseEntity.badRequest().body(response);
        }

        // Update password
        user.setPasswordHash(passwordEncoder.encode(request.getNewPassword()));
        appUserRepository.save(user);

        response.put("success", true);
        response.put("message", "Password reset successfully! Please login with your new password.");
        return ResponseEntity.ok(response);
    }

    /**
     * GET /api/auth/check-email?email=xxx
     * Check if an email is registered (used in forgot password step 1)
     */
    @GetMapping("/check-email")
    public ResponseEntity<Map<String, Object>> checkEmail(@RequestParam String email) {
        Map<String, Object> response = new HashMap<>();
        boolean exists = appUserRepository.existsByEmail(email.toLowerCase());
        response.put("exists", exists);
        response.put("message", exists ? "Email found. You can reset your password." : "No account found with this email.");
        return ResponseEntity.ok(response);
    }
}
